<?php

namespace App\Models\PvtBodies;

use Illuminate\Database\Eloquent\Factories\HasFactory;
use Illuminate\Database\Eloquent\Model;

class PharmacistsAssociations extends Model
{
    use HasFactory;
    protected $table = 'pvt_pharmacists_associations_meeting';
}
