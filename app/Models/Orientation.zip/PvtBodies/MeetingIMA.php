<?php

namespace App\Models\PvtBodies;

use Illuminate\Database\Eloquent\Factories\HasFactory;
use Illuminate\Database\Eloquent\Model;

class MeetingIMA extends Model
{
    use HasFactory;
    protected $table = 'pvt_ima_iap_meeting';
}
