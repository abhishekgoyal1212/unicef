<?php

namespace App\Models\PvtBodies;

use Illuminate\Database\Eloquent\Factories\HasFactory;
use Illuminate\Database\Eloquent\Model;

class MerchantAssociation extends Model
{
    use HasFactory;
    protected $table = 'pvt_merchant_associations_meeting';
}
