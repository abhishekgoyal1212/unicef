<?php

namespace App\Models\PvtBodies;

use Illuminate\Database\Eloquent\Factories\HasFactory;
use Illuminate\Database\Eloquent\Model;

class MeetingPractitioners extends Model
{
    use HasFactory;
    protected $table = 'private_practitionerst_meeting';
}
