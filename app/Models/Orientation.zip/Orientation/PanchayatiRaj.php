<?php

namespace App\Models\Orientation;

use Illuminate\Database\Eloquent\Factories\HasFactory;
use Illuminate\Database\Eloquent\Model;

class PanchayatiRaj extends Model
{
    use HasFactory;
    protected $table = 'orient_panchayat_rural_devlopment';
    
}
