<?php

namespace App\Models\Orientation;

use Illuminate\Database\Eloquent\Factories\HasFactory;
use Illuminate\Database\Eloquent\Model;

class EducationDepartment extends Model
{
    use HasFactory;
    protected $table = 'orient_education_depart';
}
